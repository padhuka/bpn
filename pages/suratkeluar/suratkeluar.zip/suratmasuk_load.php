			     <?php
        		include_once '../../lib/config.php';
        	?>
      
      <div id="ModalSuratmasuk" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
      <div class="col-md-11">
                <div class="modal-content" style="border-radius:10px">
                    <div class="modal-header" style="padding: 8px;border-top-style: 5px">
                        
                        <h4 class="modal-title" id="myModalLabel" style="text-align: center;padding-right: 0px">Data Surat Masuk Dibalas</h4>                        
                    </div>

                  <div class="box box-info" style="border-top-color:#dd4b39">

			<table id="example1" class="table table-bordered table-striped" width="50%">
                <thead>
                <tr>
                  		  <th>No Agenda</th>
                          <th>Asal Surat</th>
                          <th>Tgl Surat</th>
                          <th>Tgl Terima</th>
                          <th>Perihal</th>
                          <th>Disposisi</th>
                </tr>
                </thead>
                <tbody>
                <?php
                                    $j=1;
                                    $sqlcatat = "SELECT * FROM t_surat_masuk WHERE dibales=1 ORDER BY id ASC";
                                    $rescatat = mysql_query( $sqlcatat );
                                    while($catat = mysql_fetch_array( $rescatat )){
                                      //load nama disposisi
                                        $sqlkirim = "SELECT * FROM t_pengirim WHERE kode='$catat[dari]'";
                                          $qrykirim = mysql_query($sqlkirim);
                                          $hslkirim = mysql_fetch_array($qrykirim);
                                          $pengirim= $hslkirim['nama'];
                                      //load nama disposisi
                                        $namae='';
                                        //$namae2='';
                                        $sqldis = "SELECT * FROM t_disposisi AS A,t_pejabat AS B WHERE A.id_surat='$catat[no_agenda]' AND A.kpd_yth=B.nip";
                                        $qrydis = mysql_query($sqldis);
                                        $dispos='';
                                        while($hsldis = mysql_fetch_array($qrydis)){
                                          $namae= $namae.','.$hsldis['nama'];
                                          //$namae2= $namae2.','.$hsldis['nip'];
                                          $dispos=substr($namae,1);
                                          //$kddispos=substr($namae2,1);
                                        }
                                ?>                               
                        <tr style="<?php echo $stylee;?>">
                          <td><?php echo $catat['no_agenda'];?> </td>
                          <td><?php echo $pengirim;?></td>
                          <td><?php echo $catat['tgl_surat'];?></td>
                          <td><?php echo $catat['tgl_diterima'];?></td>
                          <td><?php echo $catat['isi_ringkas'];?></td>
                          <td><?php echo $dispos;?></td>
                          <td><button type="button" class="btn btn btn-default btn-circle pilih" id="<?php echo $catat['no_agenda']; ?>">Pilih</button></td>
                        </tr>
                    <?php }?>
                </tfoot>
              </table>
              </div>
              </div>
              </div>
              </div>
              </div>
              <script>
              /*var tbl = document.getElementById("example1");

                if (tbl != null) {
                            for (var i = 0; i < tbl.rows.length; i++) {
                                for (var j = 0; j < tbl.rows[i].cells.length; j++)
                                    tbl.rows[i].cells[j].onclick = function () { getval(this); };
                            }
                        }        
                        function getval(cel) {
                            //alert(cel.innerHTML);
                            var w = window.open('../file/'+cel.innerHTML);
                        } */
        //$(document).ready(function(){
             $('#example1').DataTable();
        //});


            $(".pilih").click(function (e){
                    var x = $(this).attr("id");
                    //alert(m);
                    $("#suratmasuks").val(x);
                    $("#ModalSuratmasuk").modal('hide');
                    /*$.ajax({
                    url: "suratmasuk/suratmasuk_add.php",
                    type: "GET",
                      success: function (ajaxData){
                        $("#ModalAdd").html(ajaxData);
                        $("#ModalAdd").modal('show',{backdrop: 'true'});
                      }
                    });*/
            }); 
                         
            
        
        $(".open_modal").click(function (e){
                //alert('keluar');
                var m = $(this).attr("id");    
                                    $.ajax({
                                        url: "suratmasuk/suratmasuk_edit.php",
                                        type: "GET",
                                        data : {id: m,},
                                        success: function (ajaxData){
                                          //alert(m);
                                            $("#ModalEdit").html(ajaxData);
                                            $("#ModalEdit").modal('show',{backdrop: 'true'});
                                        }
                                    });
        });
         $(".open_del").click(function (e){
                //alert('keluar');
                var m = $(this).attr("id");    
                                    $.ajax({
                                        url: "suratmasuk/suratmasuk_del.php",
                                        type: "GET",
                                        data : {id: m,},
                                        success: function (ajaxData){
                                          //alert(m);
                                            $("#ModalDelete").html(ajaxData);
                                            $("#ModalDelete").modal('show',{backdrop: 'true'});
                                        }
                                    });
        });

         $(".pdfe").click(function (e){
                var m = $(this).attr("id");                
                $.ajax({
                    url: "suratmasuk/suratmasuk_pdf.php",
                    type: "GET",
                    data : {id: m,},
                      success: function (ajaxData){
                        $("#ModalPdf").html(ajaxData);
                        $("#ModalPdf").modal('show',{backdrop: 'true'});
                      }
                    });
            }); 

         function printe(){
                //var m = $(this).attr("id");  
                //var m = $('#id').val();      
                //alert(m);        
                /*$.ajax({
                    url: "suratmasuk/suratmasuk_print.php?id="+m,
                    type: "GET",
                    success: function (ajaxData){
                    }
                    });*/
                //alert(m);
                //alert(m);
                $.ajax({
                    url: "suratmasuk/suratmasuk_pdf_print.php?id="+m,
                    type: "GET",
                      success: function (ajaxData){
                        $("#ModalPdfPrint").html(ajaxData);
                        $("#ModalPdfPrint").modal('show',{backdrop: 'true'});
                      }
                    });
            };  

            function refresh()    {
              location.reload();
              exit();
            }
      </script>