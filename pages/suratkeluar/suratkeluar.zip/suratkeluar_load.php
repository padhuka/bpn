			<?php
        		include_once '../../lib/config.php';
        	?>
          <div id="suratkeluar">
			<table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  		    <th>No Agenda</th>
                          <th>Kode Surat</th>
                          <th>Tgl Surat</th>
                          <th>Perihal</th>
                          <th>Tujuan</th>
                          <th>File</th>
                          <th><button type="button" class="btn btn btn-default btn-circle open_add"><span class="glyphicon glyphicon-plus"></span></button></th>
                </tr>
                </thead>
                <tbody>
                <?php
                                    $j=1;
                                    $sqlcatat = "SELECT * FROM t_surat_keluar ORDER BY id ASC";
                                    $rescatat = mysql_query( $sqlcatat );
                                    while($catat = mysql_fetch_array( $rescatat )){
                                ?>
                        <tr>
                          <td><?php echo $catat['no_agenda'];?></td>
                          <td><?php echo $catat['no_surat'];?></td>
                          <td><?php echo $catat['tgl_surat'];?></td>
                          <td><?php echo $catat['isi_ringkas'];?></td>
                          <?php 
                           $kode=trim($catat['tujuan']);
                            $sqlcatat2 = "SELECT * FROM m_tujuan WHERE kode='$kode'";
                            $tuj=mysql_fetch_array(mysql_query($sqlcatat2));
                            ?>
                          <td><?php echo $tuj['nama'].' - '.$catat['tujuan'];?></td>
                          <td class="pdfe" id="<?php echo $catat['file'];?>" onMouseOver="this.style.cursor='pointer'"><?php echo $catat['file'];?></td>
                          <td>                                       
                                        <button type="button" class="btn btn btn-default btn-circle open_print" id="<?php echo $catat['id']; ?>"><span class="fa fa-print"></span></button>
                                        <button type="button" class="btn btn btn-default btn-circle open_modal" id="<?php echo $catat['id']; ?>"><span class="glyphicon glyphicon-pencil"></span></button>
                                         <button type="button" class="btn btn btn-default btn-circle open_del" id="<?php echo $catat['id']; ?>"><span class="glyphicon glyphicon-remove"></span></button>

                                    </td>
                        </tr>
                    <?php }?>
                </tfoot>
              </table>
              <script>
			  $(document).ready(function(){
			       $('#example1').DataTable();	

            $(".pdfe").click(function (e){
                var m = $(this).attr("id"); 
                $.ajax({
                    url: "suratmasuk/suratmasuk_pdf.php",
                    type: "GET",
                    data : {id: m,},
                      success: function (ajaxData){
                        $("#ModalPdf").html(ajaxData);
                        $("#ModalPdf").modal('show',{backdrop: 'true'});
                      }
                    });
            }); 

  			    $(".open_add").click(function (e){
  					                    //var m = $(this).attr("id");
  					        $.ajax({
  					        url: "suratkeluar/suratkeluar_add.php",
  					        type: "GET",
  				            success: function (ajaxData){
  				            	$("#ModalAdd").html(ajaxData);
  				            	$("#ModalAdd").modal('show',{backdrop: 'true'});
  				            }
  				          });
  				  }); 
            $(".open_del").click(function (e){
                                var m = $(this).attr("id");
                                $.ajax({
                                    url: "suratkeluar/suratkeluar_del.php",
                                    type: "GET",
                                    data : {id: m,},
                                    success: function (ajaxData){
                                        $("#ModalDelete").html(ajaxData);
                                        $("#ModalDelete").modal('show',{backdrop: 'true'});
                                    }
                                });
            }); 	

            $(".open_modal").click(function (e){
                              var m = $(this).attr("id");                              
                              var nm = $(this).attr("nm");
                              $.ajax({
                                  url: "suratkeluar/suratkeluar_edit.php",
                                  type: "GET",
                                  data : {id: m,},
                                  success: function (ajaxData){
                                      $("#ModalEdit").html(ajaxData);
                                      $("#ModalEdit").modal('show',{backdrop: 'true'});
                                  }
                              });
            });	
            $(".open_print").click(function (e){
              //alert('ook');
                              var m = $(this).attr("id");  
                              var w = window.open('../file/print/suratkeluar_print.php?id='+m,'_blank');
            });

			  });
			</script>